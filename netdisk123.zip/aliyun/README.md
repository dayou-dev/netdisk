# Open API SDK for PHP developers

## Abandoned Notice

We have released a new SDK that supports Composer and gradually stop maintenance this version. Welcome to the new SDK: [**Alibaba Cloud SDK for PHP**](https://github.com/aliyun/openapi-sdk-php)

## 已废弃声明

此版本 SDK 已经废弃，请使用支持 Composer 的新版 SDK: [**Alibaba Cloud SDK for PHP**](https://github.com/aliyun/openapi-sdk-php)
