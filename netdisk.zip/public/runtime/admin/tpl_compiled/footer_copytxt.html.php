<footer>
                <hr>

                
                <p class="pull-right">Collect from webadmin</p>
                <p>© 2014 webadmin.com</p>
            </footer>