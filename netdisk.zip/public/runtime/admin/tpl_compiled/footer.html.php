
   <script src="/webadmin/Tpl/default/lib/bootstrap/js/bootstrap.js"></script>
</body>
</html>