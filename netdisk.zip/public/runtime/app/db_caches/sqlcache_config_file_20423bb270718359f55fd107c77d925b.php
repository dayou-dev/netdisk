<?php
$this->mysql_config_cache_file_time = 1577602662;
$this->timeline = 0;
$this->timezone = 0;
$this->platform = 'WINDOWS';
?>