<?php
$this->mysql_config_cache_file_time = 1538806920;
$this->timeline = 0;
$this->timezone = 0;
$this->platform = 'OTHER';
?>