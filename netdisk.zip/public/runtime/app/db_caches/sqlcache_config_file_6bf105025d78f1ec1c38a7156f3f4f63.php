<?php
$this->mysqli_config_cache_file_time = 1614067517;
$this->timeline = 1614067517;
$this->timezone = 0;
$this->platform = 'OTHER';
?>