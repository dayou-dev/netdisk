<?php
$this->mysqli_config_cache_file_time = 1674036728;
$this->timeline = 1674036728;
$this->timezone = 0;
$this->platform = 'OTHER';
?>