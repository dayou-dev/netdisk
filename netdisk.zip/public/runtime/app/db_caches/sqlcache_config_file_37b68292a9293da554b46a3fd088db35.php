<?php
$this->mysqli_config_cache_file_time = 1674043098;
$this->timeline = 1674043098;
$this->timezone = 0;
$this->platform = 'OTHER';
?>