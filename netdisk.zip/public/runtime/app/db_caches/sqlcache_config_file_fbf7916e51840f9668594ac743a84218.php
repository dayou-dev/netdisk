<?php
$this->mysqli_config_cache_file_time = 1646623269;
$this->timeline = 1646623269;
$this->timezone = 0;
$this->platform = 'OTHER';
?>