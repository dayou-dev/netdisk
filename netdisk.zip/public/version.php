<?php 
return array(
	'APP_NAME'	=>	'',
	'APP_SUB_VER'	=>	1136,
);
?>