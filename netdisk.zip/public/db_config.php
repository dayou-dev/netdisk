<?php
return array(
'DB_HOST'=>'127.0.0.1',
'DB_NAME'=>'yunpan',
'DB_USER'=>'root',
'DB_PWD'=>'root',
'DB_PORT'=>'3306',
'DB_PREFIX'=>'data_',
);
?>